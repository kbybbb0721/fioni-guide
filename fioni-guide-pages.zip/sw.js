const CACHE = "fioni-v1.1.2";
const PRECACHE = [
  "./", "./index.html", "./cheatsheet.html", "./skills.html", "./wengine.html",
  "./drive.html", "./build.html", "./team.html", "./combo.html", "./videos.html",
  "./story.html", "./faq.html", "./changelog.html", "./404.html", "./version.json",
  "./assets/style.css", "./assets/app.js", "./assets/favicon.svg",
  "./assets/icons/icon-192.png", "./assets/icons/icon-512.png", "./assets/icons/icon-maskable-512.png",
  "./assets/img/hero_show.jpg", "./assets/img/ep_cover.jpg",
  "./assets/img/v_bv1.jpg", "./assets/img/v_bv2.jpg", "./assets/img/v_bv3.jpg",
  "./assets/img/v_bv4.jpg", "./assets/img/v_bv5.jpg", "./assets/img/v_bv6.jpg"
];

self.addEventListener("message", function(e){
  if(e.data && e.data.type === "SKIP_WAITING") self.skipWaiting();
});

self.addEventListener("install", function(e){
  e.waitUntil(
    caches.open(CACHE).then(function(cache){
      return Promise.all(PRECACHE.map(function(url){
        return cache.add(new Request(url, {cache: "reload"})).catch(function(){ return null; });
      }));
    }).then(function(){ return self.skipWaiting(); })
  );
});

self.addEventListener("activate", function(e){
  e.waitUntil(
    caches.keys().then(function(keys){
      return Promise.all(keys.filter(function(k){ return k !== CACHE; }).map(function(k){ return caches.delete(k); }));
    }).then(function(){ return self.clients.claim(); })
  );
});

self.addEventListener("fetch", function(e){
  var req = e.request;
  if(req.method !== "GET") return;
  var url = new URL(req.url);
  if(url.origin !== self.location.origin) return;

  if(req.mode === "navigate"){
    e.respondWith(
      fetch(req).then(function(res){
        var copy = res.clone();
        caches.open(CACHE).then(function(c){ c.put(req, copy); });
        return res;
      }).catch(function(){
        return caches.match(req).then(function(hit){ return hit || caches.match("./index.html"); });
      })
    );
    return;
  }

  e.respondWith(
    caches.match(req).then(function(hit){
      if(hit) return hit;
      return fetch(req).then(function(res){
        var copy = res.clone();
        caches.open(CACHE).then(function(c){ c.put(req, copy); });
        return res;
      });
    })
  );
});
