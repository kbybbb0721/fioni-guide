# 菲欧妮攻略手册 · 部署包

《绝区零》3.3 菲欧妮（Phoenix）攻略站，纯静态站点，11 个页面，无需构建、无需依赖、无需后端。

数据整理于 2026-10-26，版本 3.3「重返天空的旅程」。

---

## 目录结构

```
.
├── index.html            首页（入口）
├── cheatsheet.html       一图流速查
├── skills.html           技能与机制
├── wengine.html          音擎选择
├── drive.html            驱动盘
├── build.html            养成与抽取
├── team.html             配队方案
├── combo.html            ★ 连招教学（手残分层）
├── videos.html           视频合集（B站内嵌）
├── story.html            角色与剧情（不含主线剧透）
├── faq.html              常见问题
├── 404.html              自定义错误页
├── .nojekyll             让 GitHub Pages 跳过 Jekyll 处理（别删）
└── assets/
    ├── style.css
    ├── app.js
    ├── favicon.svg
    └── img/              头图与视频封面（本地化，不依赖外链）
```

## 本地预览

直接双击 `index.html` 即可。

> 用 `file://` 打开时，B站内嵌播放器可能被浏览器拦（Referer 限制）。想要播放器正常工作，用本地服务器或部署到 https 后访问：
>
> ```bash
> python3 -m http.server 8080
> # 然后打开 http://localhost:8080
> ```

---

## 方式一：GitHub Pages（免费，推荐）

### 网页操作

1. 新建一个仓库（Public），仓库名随意，例如 `fioni-guide`。
2. 把**本文件夹里的所有内容**（不是外层文件夹）上传到仓库根目录，确保 `index.html` 在仓库根目录，而不是子文件夹里。
3. 进入仓库 `Settings` → 左侧 `Pages`。
4. `Build and deployment` → Source 选 **Deploy from a branch**；Branch 选 `main`，目录选 **/ (root)**，保存。
5. 等 1 分钟左右，访问：

```
https://<你的用户名>.github.io/fioni-guide/
```

### 命令行操作

```bash
cd fioni-guide-pages          # 解压后的目录
 git init
 git add -A
 git commit -m "菲欧妮攻略站"
 git branch -M main
 git remote add origin https://github.com/<用户名>/fioni-guide.git
 git push -u origin main
```

推完之后仍然要去 `Settings → Pages` 选 `main` / `/ (root)` 一次。

### 想要短链接

- 仓库名取 `<用户名>.github.io`，站点会直接挂在 `https://<用户名>.github.io/`（一个账号只能有一个）。
- 有自己的域名：在 `Settings → Pages → Custom domain` 填域名，并在 DNS 加一条 CNAME 指向 `<用户名>.github.io`。

---

## 方式二：Vercel / Netlify（拖拽即上线）

两个平台都支持"拖文件夹"：

- **Netlify**：登录 → `Add new site` → `Deploy manually` → 把本文件夹拖进去 → 拿到 `https://xxx.netlify.app`。
- **Vercel**：`Add New… → Project` → 选择 `Deploy` 里的拖拽区域上传文件夹（或连 Git 仓库，Framework 选 **Other**，Build Command 留空，Output Directory 留空）。

两者都自带 https，播放器可直接用。

---

## 方式三：任意静态空间 / 对象存储

把整个文件夹原样上传到网站根目录即可，不需要 PHP、Node 或数据库。只要能把 `index.html` 映射到访问路径，就能跑。

---

## 需要注意的两件事

1. **视频播放器**：`videos.html` 与 `combo.html` 用 B站官方播放器 iframe 内嵌，每个视频都另有「去B站原视频」链接兜底。若你的网络环境访问 B站受限，播放器会空白，点原链接即可。
2. **素材版权**：头图为官方投稿的封面素材，视频封面与视频版权归各 UP 主 / 米哈游所有。个人自用、小范围分享没问题；**如果要公开传播或商用，请自行确认授权**，或把 `assets/img/` 里的图片换成你自己的截图。

## PWA：装到桌面 / 离线可用

本站已内置 PWA 支持（`manifest.webmanifest` + `sw.js` + 192/512/maskable 图标）。

- **部署到 https 后**（GitHub Pages / Netlify / Vercel 都行），手机浏览器会提示「添加到主屏幕」。
- **iPhone**：Safari 打开 → 分享 → 添加到主屏幕。图标与名称会用 `apple-touch-icon` 与 `apple-mobile-web-app-title`。
- **Android**：Chrome 菜单 → 安装应用 / 添加到主屏幕。打开后是全屏 standalone，没有地址栏。
- **离线**：首次访问后，Service Worker 会预缓存 12 个页面 + 样式 + 全部图片，断网也能翻页（B站播放器需联网，离线时点「去B站原视频」也没用，这是正常的）。
- **长按图标**有快捷方式：连招教学 / 一图流速查。

### 改了内容怎么让用户看到新版？

Service Worker 是「缓存优先」，所以每次改完页面，请把 `sw.js` 第一行的版本号 +1：

```js
const CACHE = "fioni-v1.0.1";   // 原来是 v1.0.0
```

用户下次打开会自动更新缓存并清理旧版本。不改版本号的话，老访客可能一直看到旧页面。

> `file://` 直接双击打开时 Service Worker 不生效（浏览器限制），不影响阅读，只是没有离线能力。

---

## 想改内容？

- 文字：直接用编辑器改对应的 `.html`（内容都是静态文本，没有框架语法）。
- 配色：改 `assets/style.css` 顶部的 `:root` 变量（`--red` / `--org` 决定主色）。
- 加页面：复制任意一个 html，改标题与 `<main>` 里的内容，再在每页侧边栏 `.nav` 里加一条链接。

---

整理：2026-10-26 · 数据来源：米游社 Asgater 系列、4399 创作体验服一图流、3DM 转载、好游网操作讲解、B站 wiki、B站 UP 主手法视频、官方角色档案与物料。
