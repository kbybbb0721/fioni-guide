(function(){
  var CURRENT_VERSION = "1.1.1";
  var body = document.body;

  /* ---------- 菜单 ---------- */
  document.addEventListener('click', function(e){
    if(e.target.closest('.burger')){ body.classList.toggle('menu-open'); return; }
    if(e.target.closest('.mask')){ body.classList.remove('menu-open'); return; }
    var navLink = e.target.closest('.nav a');
    if(navLink && window.innerWidth <= 1024){ body.classList.remove('menu-open'); }

    /* ---------- 视频懒加载 ---------- */
    var play = e.target.closest('[data-play]');
    if(play){
      e.preventDefault();
      var bv = play.getAttribute('data-play');
      var wrap = play.closest('.player-slot');
      if(wrap && !wrap.querySelector('iframe')){
        var f = document.createElement('iframe');
        f.src = 'https://player.bilibili.com/player.html?bvid=' + bv + '&page=1&high_quality=1&danmaku=0&autoplay=0';
        f.setAttribute('allowfullscreen','true');
        f.setAttribute('scrolling','no');
        f.setAttribute('frameborder','0');
        wrap.innerHTML = '';
        wrap.appendChild(f);
      }
      return;
    }

    /* ---------- 复制 ---------- */
    var copy = e.target.closest('[data-copy]');
    if(copy){
      var node = document.querySelector(copy.getAttribute('data-copy'));
      var text = node ? (node.innerText || node.textContent || '') : '';
      var done = function(){
        var old = copy.textContent;
        copy.textContent = '已复制 ✓';
        setTimeout(function(){ copy.textContent = old; }, 1400);
      };
      if(navigator.clipboard && navigator.clipboard.writeText){
        navigator.clipboard.writeText(text).then(done).catch(done);
      } else {
        var ta = document.createElement('textarea');
        ta.value = text; document.body.appendChild(ta); ta.select();
        try{ document.execCommand('copy'); }catch(err){}
        document.body.removeChild(ta); done();
      }
    }
  });

  document.addEventListener('keydown', function(e){
    if(e.key === 'Escape'){ body.classList.remove('menu-open'); }
  });

  /* ---------- 左右方向键翻页 ---------- */
  var prev = document.querySelector('.pager a[rel="prev"]');
  var next = document.querySelector('.pager a[rel="next"]');
  document.addEventListener('keydown', function(e){
    if(e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
    if(e.key === 'ArrowLeft' && prev) location.href = prev.href;
    if(e.key === 'ArrowRight' && next) location.href = next.href;
  });

  /* ---------- 新版本提示 ---------- */
  var bar = null;
  function showUpdate(ver){
    if(bar) return;
    bar = document.createElement('div');
    bar.className = 'update-bar';
    bar.innerHTML = '<span>发现新版本' + (ver ? ' <b>v' + ver + '</b>' : '') + '，刷新后生效</span>' +
                    '<button type="button" class="btn red">刷新</button>' +
                    '<button type="button" class="ub-x" aria-label="关闭">×</button>';
    bar.querySelector('.btn').addEventListener('click', function(){
      if(navigator.serviceWorker && navigator.serviceWorker.getRegistration){
        navigator.serviceWorker.getRegistration().then(function(reg){
          if(reg && reg.waiting) reg.waiting.postMessage({type:'SKIP_WAITING'});
          location.reload();
        }).catch(function(){ location.reload(); });
      } else { location.reload(); }
    });
    bar.querySelector('.ub-x').addEventListener('click', function(){
      bar.remove(); bar = null;
    });
    body.appendChild(bar);
  }

  function checkVersion(){
    if(location.protocol === 'file:') return;
    fetch('version.json?ts=' + Date.now(), {cache: 'no-store'})
      .then(function(r){ return r.ok ? r.json() : null; })
      .then(function(j){
        if(j && j.version && j.version !== CURRENT_VERSION) showUpdate(j.version);
      })
      .catch(function(){});
  }
  setTimeout(checkVersion, 3000);
  setInterval(checkVersion, 3600000);

  /* ---------- Service Worker ---------- */
  if ("serviceWorker" in navigator && location.protocol !== "file:") {
    var hadController = !!navigator.serviceWorker.controller;
    try {
      navigator.serviceWorker.register("sw.js").then(function(reg){
        if(hadController && reg.waiting) showUpdate('');
        reg.addEventListener('updatefound', function(){
          var sw = reg.installing;
          if(!sw) return;
          sw.addEventListener('statechange', function(){
            if(sw.state === 'installed' && navigator.serviceWorker.controller) showUpdate('');
          });
        });
      }).catch(function(){});
      navigator.serviceWorker.addEventListener('controllerchange', function(){
        if(hadController && !bar) showUpdate('');
      });
    } catch (e) {}
  }

  /* ---------- 本机阅读记录（零依赖 · 不追踪） ---------- */
  (function(){
    try{
      var KEY = 'fioni.read.v1';
      var page = location.pathname.split('/').pop() || 'index.html';
      if(page.indexOf('.html') < 0) page = 'index.html';
      var db;
      try { db = JSON.parse(localStorage.getItem(KEY) || '{}'); } catch(e) { db = {}; }
      if(!db.visits){ db.visits = {}; db.first = Date.now(); db.total = 0; }
      db.total = (db.total || 0) + 1;
      db.last = Date.now();
      var v = db.visits[page] || {n:0, last:0};
      v.n++; v.last = Date.now();
      db.visits[page] = v;
      localStorage.setItem(KEY, JSON.stringify(db));

      document.querySelectorAll('.nav a').forEach(function(a){
        var href = a.getAttribute('href');
        if(href && db.visits[href] && db.visits[href].n > 0) a.classList.add('read');
      });

      if(page === 'index.html'){
        var pages = ['index.html','cheatsheet.html','skills.html','wengine.html','drive.html','build.html','team.html','combo.html','videos.html','story.html','faq.html','changelog.html'];
        var read = pages.filter(function(p){ return db.visits[p]; }).length;
        var pct = Math.round(read / pages.length * 100);
        var el = document.createElement('div');
        el.className = 'card';
        el.style.marginTop = '26px';
        el.innerHTML = '<div class="card-title">你的阅读进度 <span class="tag">仅本机</span></div>'
          + '<div style="display:flex;align-items:center;gap:12px;margin:10px 0 8px">'
          + '<b style="font-size:22px;line-height:1">' + read + ' / ' + pages.length + '</b>'
          + '<div style="flex:1;height:6px;border-radius:6px;background:#22222b;overflow:hidden"><i style="display:block;height:100%;width:' + pct + '%;background:linear-gradient(90deg,#ff8a3d,#ff3b2f)"></i></div>'
          + '</div>'
          + '<p class="small muted" style="margin:0">一共打开过 ' + db.total + ' 次。记录只存在你自己的浏览器里，不上传、不追踪、没有第三方脚本。</p>';
        var main = document.querySelector('.main');
        var pager = document.querySelector('.pager');
        if(main){ if(pager){ main.insertBefore(el, pager); } else { main.appendChild(el); } }
      }
    } catch(e) {}
  })();

})();
